# -*- coding: utf-8 -*-
from . import loan
from . import res_config_settings