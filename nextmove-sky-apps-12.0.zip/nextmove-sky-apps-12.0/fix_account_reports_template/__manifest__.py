# -*- coding: utf-8 -*-
{
    'name': "SW - Fix Account Reports Template ",
    'summary': """
        """,
    'description': """ 
                 """,
    'author': "Smart Way Business Solutions",
    'website': "https://www.smartway.co",
    'category': 'Accounting',
    'version': '12.0.1.0',
    'depends': ['account_reports'],
    'data': [
        "viwes/fix_account_reports_template.xml"
        
        ],
}
