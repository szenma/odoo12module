# -*- coding: utf-8 -*-

from . import sale
from . import res_config_settings
from . import res_company