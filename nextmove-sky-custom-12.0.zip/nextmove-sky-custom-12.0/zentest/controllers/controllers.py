# -*- coding: utf-8 -*-
from odoo import http

# class Zentest(http.Controller):
#     @http.route('/zentest/zentest/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/zentest/zentest/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('zentest.listing', {
#             'root': '/zentest/zentest',
#             'objects': http.request.env['zentest.zentest'].search([]),
#         })

#     @http.route('/zentest/zentest/objects/<model("zentest.zentest"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('zentest.object', {
#             'object': obj
#         })