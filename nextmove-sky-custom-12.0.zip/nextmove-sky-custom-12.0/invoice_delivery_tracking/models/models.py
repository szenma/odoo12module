# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SaleOrder(models.Model):
    _inherit = 'sale.order'
    
    invoice_received = fields.Boolean('Invoice Received')
    delivery_note_received = fields.Boolean('Delivery Note Received')
    
    

class StockPicking(models.Model):
    _inherit = 'stock.picking'
    
    is_received = fields.Boolean('Is received', store=True, compute="_compute_is_recieved_delivery")
    
    @api.depends('sale_id.delivery_note_received')
    def _compute_is_recieved_delivery(self):
        for rec in self.filtered(lambda x:x.sale_id):
            rec.is_received = rec.sale_id.delivery_note_received

class AccountInvoice(models.Model):
    _inherit = 'account.invoice'
    
    is_received = fields.Boolean('Is recieved',store=True, compute="_compute_is_received_invoice")
    
    @api.depends('invoice_line_ids.sale_line_ids.order_id.invoice_received')
    def _compute_is_received_invoice(self):
        for rec in self:
            is_recieved = True
            for line in rec.invoice_line_ids:
                for sale_line in line.sale_line_ids:
                    if not sale_line.order_id.invoice_received:
                        is_recieved = False
            rec.is_received = is_recieved