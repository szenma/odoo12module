# -*- coding: utf-8 -*-
{
    'name': "SW - Invoice & Delivery Tracking",
    'summary': """
    This module adds 2 checkboxes for invoice and delivery note tracking
       """,
    'description': """
    """,
    'author': "Smart Way Business Solutions",
    'website': "https://www.smartway.co",
    'category': 'SKY',
    'version': '12.0.1.0',
    'depends': ['base','sale','stock','account','sale_stock'],
    'data': [
        'views/views.xml'
    ],
}
