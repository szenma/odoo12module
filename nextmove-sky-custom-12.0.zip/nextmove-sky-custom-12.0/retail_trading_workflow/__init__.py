# -*- coding: utf-8 -*-

from . import models
from . import wizard

from odoo import api, tools, SUPERUSER_ID


def post_init_hook(cr, registry):
    env = api.Environment(cr, SUPERUSER_ID, {})
    env['account.journal'].search([('id','=','1')]).update_poted = True