# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.tests.common import Form
from odoo.addons import decimal_precision as dp
from odoo.exceptions import UserError

class StockRule(models.Model):
    _inherit = 'stock.rule'
    
    @api.multi
    def _prepare_purchase_order_line(self, product_id, product_qty, product_uom, values, po, partner):
        vals = super(StockRule, self)._prepare_purchase_order_line(product_id, product_qty, product_uom, values, po, partner)
        analytic_account = self._context.get("analytic_account",False)
        if  analytic_account:
            vals["account_analytic_id"] = analytic_account
        return vals

class ResPartner(models.Model):
    _inherit = 'res.partner'
    
    customer_type = fields.Selection([('retail', 'Retail'), ('trading', 'Trading')], string="Customer Type")


class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'
    
    sale_id = fields.Many2one('sale.order')
    
    @api.multi
    @api.returns('self', lambda value: value.id)
    def copy(self, default=None):
        default = dict(default or {})
        if self.sale_id.customer_type == 'trading':
            default['origin'] = self.origin if self.origin else ""
        return super(PurchaseOrder, self).copy(default)
    
class SaleOrder(models.Model):
    _inherit = 'sale.order'
    
    customer_type = fields.Selection([('retail', 'Retail'), ('trading', 'Trading')], string="Customer Type", inverse="_inverse_customer_type", required=True)
    total_cost = fields.Float(string='Cost', digits=dp.get_precision('Product Price'), compute="compute_total_cost", readonly=True, store=True)
    total_margin_amount = fields.Float(string='Margin Amount', compute="_compute_sale_profit", store=True)
    total_margin_percentage = fields.Float(string='Margin Percentage', compute="_compute_sale_profit", digits=dp.get_precision('Product Price'), store=True)
    purchase_ids = fields.One2many('purchase.order','sale_id')
    show_generate_button = fields.Boolean(compute="_compute_show_generation_button")
    retail_seq = fields.Char(default=lambda self: 'New')
    trading_seq = fields.Char(default=lambda self: 'New')
    procurement_responsible = fields.Many2one("res.users", string="Procurement responsible")
    
    @api.onchange("customer_type")
    def _inverse_customer_type(self):
        a_ac = self.env["account.analytic.account"].search([('name','ilike',self.customer_type)])
        if a_ac:
            self.analytic_account_id = a_ac.id
    
    
    @api.model
    def create(self,vals):
        if vals.get('customer_type',False) == 'retail':
            vals['name'] = self.env['ir.sequence'].next_by_code('sale.order.ret') 
            return super(SaleOrder, self.with_context(force_stop = True)).create(vals)
        elif vals.get('customer_type',False) == 'trading':
            vals['name'] = self.env['ir.sequence'].next_by_code('sale.order.tr')
            return super(SaleOrder, self.with_context(force_stop = True)).create(vals)
            
            
        return super(SaleOrder, self).create(vals)
    
    @api.multi
    def write(self, values):
        for rec in self:
            if (rec.retail_seq or rec.trading_seq) and 'customer_type'  in values:
                raise UserError("You can't change the customer after generating a sequence number, please cancel this record and create a new one.")
        return super(SaleOrder, self).write(values)
    
    def _compute_show_generation_button(self):
        for rec in self.filtered(lambda x:x.customer_type == 'trading'):
            show = False;
            for line in rec.order_line:
                if not line.purchase_line_ids:
                    show = True
            rec.show_generate_button = show
        
    @api.depends('total_cost','amount_untaxed')
    def _compute_sale_profit(self):
        total_cost = 0
        for rec in self.filtered(lambda x:x.customer_type == 'trading'):
            rec.total_margin_amount = rec.amount_untaxed - rec.total_cost  
            rec.total_margin_percentage = (rec.total_margin_amount / rec.amount_untaxed if rec.amount_untaxed else 0.0)*100
    
    
    @api.depends("order_line.cost" , "order_line.product_uom_qty")
    def compute_total_cost(self):
       for rec in self.filtered(lambda x:x.customer_type == 'trading'):
           total_cost = 0
           for line in rec.order_line:
               total_cost += (line.cost * line.product_uom_qty)
               
           rec.total_cost = total_cost
    
    @api.onchange('partner_id')
    def set_customer_type(self):
        for rec in self.filtered(lambda x:x.partner_id != False):
            rec.customer_type = rec.partner_id.customer_type
            
            
    def action_confirm(self):
        res = super(SaleOrder, self.with_context(analytic_account=self.analytic_account_id.id)).action_confirm()
        for rec in self.filtered(lambda x:x.customer_type == 'trading'):
            for line in rec.order_line:
                selected_purchase_lines = line.purchase_line_ids.filtered(lambda x:x.is_selected)
                sale_moves = line.move_ids
                selected_purchase_lines.write({'move_dest_ids':[(4, move.id) for move in sale_moves]}) 
        return res
            
    def generate_po(self):
        dummy_vendor = self.env.ref('retail_trading_workflow.dummy_vendore')
        purchase_order_obj = self.env['purchase.order']
        for rec in self:
            if rec.order_line:
                with Form(purchase_order_obj, view='purchase.purchase_order_form') as purchase_order:
                    purchase_order.partner_id = dummy_vendor
                    purchase_order.origin = rec.name
                    purchase_order.user_id = rec.procurement_responsible
                    for line in rec.mapped('order_line').filtered(lambda x:not x.purchase_line_ids):
                        with purchase_order.order_line.new() as order_line:
                            order_line.product_id = line.product_id
                            order_line.product_qty = line.product_uom_qty
                            order_line.sale_order_line_id = line
                            order_line.name = line.name
                    pucrhase_order = purchase_order.save()
                    rec.purchase_ids = [(4,pucrhase_order.id)]
    
    
class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'
    
    purchase_line_ids = fields.One2many('purchase.order.line', 'sale_order_line_id', readonly=False)
    cost = fields.Float(string='Cost', compute="_compute_cost" , store=True)
    margin_amount = fields.Float(string='Margin Amount', compute="_compute_line_profit", store=True)
    margin_percentage = fields.Float(string='Margin Percentage', compute="_compute_line_profit", store=True, digits=dp.get_precision('Product Price'))  
    
    @api.depends('purchase_line_ids','purchase_line_ids.price_unit','product_id','purchase_line_ids.currency_id')
    def _compute_cost(self):
        for line in self:
            selected_line = line.purchase_line_ids.filtered(lambda x:x.is_selected)
            if selected_line:
                line.cost = selected_line.order_id.currency_id._convert(selected_line.price_unit,line.currency_id,line.order_id.company_id,fields.Date.today())
            else:
                line.cost = line.product_id.standard_price
        self.mapped('order_id').compute_total_cost()
    
    @api.depends('cost', 'product_uom_qty','price_subtotal')
    def _compute_line_profit(self):
        for rec in self.filtered(lambda x:x.order_id.customer_type == 'trading'):
            rec.margin_amount = rec.price_subtotal - (rec.cost * rec.product_uom_qty)
            rec.margin_percentage = (rec.margin_amount / rec.price_subtotal if rec.price_subtotal > 0 else 0)*100

    def set_pol(self):
        selected_pol = self.purchase_line_ids.filtered(lambda x:x.is_selected)
        if len(selected_pol)>1 or   not selected_pol  or selected_pol.order_id.state=='cancel':
           raise UserError("Please select one not canceled line.")
        return  
    
    def select_pol(self):
         return {
                 "type": "ir.actions.act_window",
                "res_model": "sale.order.line",
                "views": [[self.env.ref('retail_trading_workflow.sale_order_line_puchase_selection_view').id, "form"]],
                "res_id": self.id ,
                "target": "new",
                }
    
class PurchaseOrderLine(models.Model):
    _inherit = 'purchase.order.line'
    
    sale_order_line_id = fields.Many2one('sale.order.line', copy=True)
    is_selected = fields.Boolean('Selected', copy=False, default=False)
    sale_state = fields.Selection([
    ('draft', 'Quotation'),
    ('sent', 'Quotation Sent'),
    ('sale', 'Sales Order'),
    ('done', 'Locked'),
    ('cancel', 'Cancelled'),
    ],related="sale_order_line_id.state")

        
class StockPicking(models.Model):
    _inherit = 'stock.picking'
    
    sale_type = fields.Selection([('retail', 'Retail'), ('trading', 'Trading')], related="sale_id.customer_type", string="Customer Type")
        
    #===========================================================================
    # def print_invoice(self):
    #     invoice = self.sale_id.invoice_ids.filtered(lambda x: x.state !='cancel' and x.type=='out_invoice')
    #     return self.env.ref('account.account_invoices').report_action(invoice[-1])
    #===========================================================================
    
    @api.multi
    def action_done(self):
        res = super(StockPicking, self).action_done()
        for rec in self.filtered(lambda x:x.sale_id.customer_type == 'retail' and x.picking_type_code == 'incoming'):
            product_ids = rec.mapped('move_lines.product_id.id')
            invoice_ids = self.env['account.invoice']
            for line in rec.sale_id.order_line.filtered(lambda x:x.product_id.id in product_ids):
                line_id = line.invoice_lines.filtered(lambda x: x.invoice_id.state != 'cancel' and x.invoice_id.type == 'out_invoice').sorted(lambda x:x.invoice_id.id)
                line_id = line_id and line_id[0]
                if line_id:
                    for xx, item in enumerate(line_id.invoice_id.invoice_line_ids):
                        if item.id == line_id.id:
                            break
                    inv_id = line_id.invoice_id
                    need_open = inv_id.state != 'draft'
                    invoice_ids = need_open and invoice_ids | inv_id or  invoice_ids
                    inv_id.action_invoice_cancel()
                    inv_id.action_invoice_draft()
                    inv_id.state = 'draft'
                    with Form(inv_id,'account.invoice_form') as inv:
                        with inv.invoice_line_ids.edit(xx) as ail:
                            ail.quantity = line.qty_delivered
            invoice_ids and invoice_ids.action_invoice_open()
        return res
    
class IrSeq(models.Model):
    _inherit = 'ir.sequence'
    
    
    @api.model
    def next_by_code(self, sequence_code):
        if sequence_code == 'sale.order' and self._context.get('force_stop',False):
            seq = self.search([('code','=',sequence_code)],limit=1)
            return seq.prefix+str(seq.number_next_actual) if seq else ""
        
        res = super(IrSeq, self).next_by_code(sequence_code)
        return res 
    
class AccountInvoice(models.Model):
    _inherit = "account.invoice"
    
    customer_type = fields.Selection([('retail', 'Retail'), ('trading', 'Trading')], string="Customer Type", related="invoice_line_ids.sale_line_ids.order_id.customer_type", store=True)
    
