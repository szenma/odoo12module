# -*- coding: utf-8 -*-
{
    'name': "SW - Retail Trading Workflow",
    'summary': """
    This module allows to manage the retail and trading department as per Sky Creative requirements.
       """,
    'description': """
    """,
    'author': "Smart Way Business Solutions",
    'website': "https://www.smartway.co",
    'category': 'SKY',
    'version': '12.0.1.1',
    'depends': ['base', 'sale', 'sales_team', 'stock', 'account', 'sale_stock', 'purchase','account_cancel'],
    'data': [
        'data/sale_order_seq.xml',
        'wizard/import_sale_order_line.xml',
        'views/views.xml',
        'security/ir.model.access.csv',
        'data/res_partner_data.xml'],
     'post_init_hook': 'post_init_hook',   
    
}
