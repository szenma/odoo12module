# -*- coding: utf-8 -*-

{
    'name': 'Employee Documents',
    'version': '12.0.1.0.1',
    'summary': """Manages Employee Documents With Expiry Notifications.""",
    'description': """Manages Employee Related Documents with Expiry Notifications.""",
    'category': 'Generic Modules/Human Resources',
    'author': 'zen',
    'company': 'zen',
    'maintainer': 'zen',
    'website': "",
    'depends': ['base', 'hr'],
    'data': [
        'security/ir.model.access.csv',
        'views/employee_check_list_view.xml',
        'views/employee_document_view.xml',
    ],
    'demo': ['data/data.xml'],
    'images': ['static/description/banner.jpg'],
    'license': 'AGPL-3',
    'installable': True,
    'auto_install': False,
    'application': False,
}
