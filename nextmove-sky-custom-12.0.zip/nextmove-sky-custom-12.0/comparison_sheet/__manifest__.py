# -*- coding: utf-8 -*-
{
    'name': "SW - Comparison Sheet",
    'summary': """
    Comparison Sheet.
""",
    'description': """
    Comparison Sheet.
    """,
    'author': "Smart Way Business Solutions",
    'website': "https://www.smartway-jo.com",
    'category': 'SKY',
    'version': '12.0.1.0',
    'depends': ['base','sale','retail_trading_workflow'],
    'data': [
        "views/views.xml"
    ],
}