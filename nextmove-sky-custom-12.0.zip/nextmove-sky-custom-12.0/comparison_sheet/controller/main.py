# -*- coding: utf-8 -*-
import json
import base64
from odoo import http
from odoo.http import request,content_disposition
from odoo.addons.web.controllers.main import ReportController
from odoo.exceptions import UserError
 
  
class CustomReportController(ReportController):
      
    @http.route([
        '/report/<converter>/<reportname>',
        '/report/<converter>/<reportname>/<docids>',
    ], type='http', auth='user', website=True)
    def report_routes(self, reportname, docids=None, converter=None, **data):
        if reportname == 'sale_order.report_comparison_sheet' and docids:
            doc_ids = docids.split(',')
            ids = [int(x) for x in  doc_ids]
            orders = request.env['sale.order'].browse(ids)
            if any(order.customer_type != "trading" for order in orders):
                raise UserError('One or more of selected records is not trading orders.')
        elif reportname == 'purchase_order.report_comparison_sheet' and docids:
            doc_ids = docids.split(',')
            ids = [int(x) for x in  doc_ids]
            pos = request.env["purchase.order"].browse(ids)
            if any(not po.sale_id for po in pos):
                raise UserError('This RFQ is not linked with a Quotation, therefore, no comparison sheet is available ')
              
          
        return super(CustomReportController, self).report_routes(reportname, docids, converter, **data) 
  
  
       
    @http.route(['/report/download'], type='http', auth="user")
    def report_download(self, data, token):
        requestcontent = json.loads(data)
        url = requestcontent[0]
        if 'sale_order.report_comparison_sheet' in url:
            id = int(url.split('/')[-1])
            sale_order = request.env["sale.order"].browse(id)
            if all(order.customer_type == "trading" for order in sale_order):
                file =  base64.b64decode(sale_order.print_comparison_sheet())
                file_name = 'Comparison-Sheet.xlsx'
                return request.make_response(file,
                                              [('Content-Type', 'text/plain'),
                                                 ('Content-Disposition' ,content_disposition(file_name))])
                  
        elif 'purchase_order.report_comparison_sheet' in url:
            id = int(url.split('/')[-1])
            po = request.env["purchase.order"].browse(id)
            so = po.sale_id if po else False
            if so :
                file =  base64.b64decode(so.print_comparison_sheet())
                file_name = 'Comparison-Sheet.xlsx'
                return request.make_response(file,
                                              [('Content-Type', 'text/plain'),
                                                 ('Content-Disposition' ,content_disposition(file_name))])
              
        return super(CustomReportController, self).report_download(data, token)
