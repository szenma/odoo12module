# -*- coding: utf-8 -*-

from odoo import models, fields, api
import base64
import xlsxwriter
import io
import tempfile
from xlsxwriter.utility import xl_rowcol_to_cell
from odoo.addons import decimal_precision as dp



class PurchaseOrderLine(models.Model):
    _inherit = "purchase.order.line"
    
    
    note = fields.Text("Note")

        
        
class SaleOrder(models.Model):
    _inherit = "sale.order"
    
    
    grade = fields.Selection([('low','Low'),('medium','Medium'),('high','High')], string="Grade")
    procurement_responsible = fields.Many2one("res.users", string="Procurement responsible")
    
    def show_related_rfq(self):
        action = {
            'name':"RFQ's",
            'type': 'ir.actions.act_window',
            'res_model': 'purchase.order',
            'target': 'current',
        }
        purchase_ids = self.purchase_ids.ids
        if len(purchase_ids) == 1:
            purchase = purchase_ids[0]
            action['res_id'] = purchase
            action['view_mode'] = 'form'
            form_view = [(self.env.ref('purchase.purchase_order_form').id, 'form')]
        else:
            action['view_mode'] = 'tree,form'
            action['domain'] = [('id', 'in', purchase_ids)]
        return action
        
    
    def print_comparison_sheet(self):
        for rec in self:
            temp_file = tempfile.NamedTemporaryFile(suffix=".xlsx")
            workbook = xlsxwriter.Workbook(temp_file.name)
            worksheet = workbook.add_worksheet('Sheet 1')
            number_of_lines = len(rec.order_line)
            
            #prepare sheet style per each part of the sheet 
            header_style = workbook.add_format({'bold': True,'font_size':16,'font_name':'Calibri Light'})
            body_style = workbook.add_format({'bold': True,'font_size':9,'font_name':'Calibri Light'})
            table_header_style = workbook.add_format({'bold': True,'font_size':11,'font_name':'Calibri Light'})
            purchase_header = workbook.add_format({'bold': True,'font_size':11,'font_name':'Calibri Light','bg_color': '#C0C0C0'})
            purchase_body = workbook.add_format({'font_name':'Calibri Light','bg_color': '#9999FF'})
            Lowest_price_body = workbook.add_format({'font_name':'Calibri Light','bg_color': '#FFFFCC','bold': True,})
            mini_price_style = workbook.add_format({'font_name':'Calibri Light','bg_color': '#339966'})
            
            # Sale order header general information 
            worksheet.set_row(1,30)
            worksheet.write(1, 0, "COSTING SHEET",header_style)
            worksheet.write(2, 0, "Grade: ",body_style)
            worksheet.write(2, 1, rec.grade if rec.grade else "" ,body_style)
            worksheet.write(3, 0, "PROC REP: ",body_style)
            worksheet.write(3, 1, rec.procurement_responsible.name if rec.procurement_responsible else "",body_style)
            worksheet.write(4, 0, "SKY REF # ",body_style)
            worksheet.write(4, 1, rec.name,body_style)
            worksheet.write(5, 0, "Client REF # ",body_style)
            worksheet.write(5, 1, rec.client_order_ref if rec.client_order_ref else "",body_style)
            worksheet.write(6, 0, "Date ",body_style)
            worksheet.write(6, 1, str(rec.date_order) if rec.date_order else False,body_style)
            
            #sale order table header 
            worksheet.write(8, 0, "# ",table_header_style)
            worksheet.write(8, 1, "Risk/ HZ",table_header_style)
            worksheet.write(8, 2, "Part #",table_header_style)
            worksheet.write(8, 3, "Description",table_header_style)
            worksheet.write(8, 4, "Qty",table_header_style)
            worksheet.write(8, 5, "Unit",table_header_style)
            
            #each related purchase header information 
            row = 7
            column = 7
            for purchase in rec.purchase_ids:
                row = 7
                worksheet.write(row, column, purchase.partner_id.name,purchase_header)
                worksheet.write(row, column+1, purchase.note if purchase.note else "",purchase_header)
                row +=1 
                worksheet.write(row, column, "Price")
                worksheet.write(row, column+1, "Ext Price")
                worksheet.write(row, column+2, "Scheduled Date")
                worksheet.write(row, column+3, "Note")
                column+=5
            
            #generate the lowest price table info header
            worksheet.write(row-1, column, "Lowest Price",Lowest_price_body)
            worksheet.write(row, column, "Price",Lowest_price_body)
            worksheet.write(row, column+1, "Ext Price",Lowest_price_body)
            worksheet.write(row, column+2, "Margin%",table_header_style)
            worksheet.write(row, column+3, "Selling Unit Price",table_header_style)
            worksheet.write(row, column+4, "Total",table_header_style)
            
                
            
            #start generating each sale order line required informaion ..
            #(number,default_code,name,product_uom_qty,product_uom, purchase related lines information (price , total price ,Scheduled Date ))
            
            row = 9
            for line in rec.order_line:
                worksheet.write(row, 0, line.number)
                worksheet.write(row, 1,"")
                worksheet.write(row, 2,line.product_id.default_code)
                worksheet.write(row, 3,line.name)
                worksheet.write(row, 4,line.product_uom_qty)
                qty_cell = xl_rowcol_to_cell(row, 4)
                worksheet.write(row, 5,line.product_uom.name)
                column = 7
                purchase_price = []
                subtotal_purchase_price = []
                for price in line.purchase_line_ids.mapped("price_unit"):
                    purchase_price.append(line.purchase_line_ids[0].order_id.currency_id._convert(price,line.order_id.currency_id,line.company_id,fields.Date.today()))
                for sub_price in line.purchase_line_ids.mapped("price_subtotal"):
                    subtotal_purchase_price.append(line.purchase_line_ids[0].order_id.currency_id._convert(sub_price,line.order_id.currency_id,line.company_id,fields.Date.today()))
                minimum_purchase_price = min(purchase_price) if line.purchase_line_ids else 0
                minimum_purchase_total_price = min(subtotal_purchase_price) if line.purchase_line_ids else 0
                for purchase in rec.purchase_ids:
                    p_line = purchase.order_line.filtered(lambda x:x.sale_order_line_id == line)
                    if p_line:
                        converted_price = p_line.order_id.currency_id._convert(p_line.price_unit,line.order_id.currency_id,line.company_id,fields.Date.today())
                        worksheet.write(row, column,converted_price ,mini_price_style if converted_price == minimum_purchase_price else purchase_body )
                        worksheet.write(row, column+1,converted_price*p_line.product_qty,purchase_body)
                        worksheet.write(row, column+2, str(p_line.date_planned) if p_line.date_planned else "",purchase_body)
                        worksheet.write(row, column+3, p_line.note if p_line.note else "",purchase_body)
                    else :
                         worksheet.write(row, column, "",purchase_body)
                         worksheet.write(row, column+1, "",purchase_body)
                         worksheet.write(row, column+2, "",purchase_body)
                         worksheet.write(row, column+3, "",purchase_body)
                    column+=5
                
                #generating the minimum price , minimum ext_price , Selling Unit Price , Total
                worksheet.write(row, column,minimum_purchase_price)
                lowest_price_cell =  xl_rowcol_to_cell(row, column)
                worksheet.write(row, column+1,minimum_purchase_total_price)
                margin_cell =  xl_rowcol_to_cell(row, column+2)
                worksheet.write_formula(row, column+3,"=%s+%s*%s"%(lowest_price_cell,lowest_price_cell,margin_cell))
                selling_unit_price_cell =  xl_rowcol_to_cell(row, column+2)
                worksheet.write(row, column+4,"=%s*%s"%(selling_unit_price_cell,qty_cell))
                row+=1
            
            
            #generating purchase terms and conditions , purchase total 
            column = 3
            worksheet.write(row, column,"Total",body_style)
            worksheet.write(row+1, column,"Terms & conditions",body_style)
            for p in rec.purchase_ids:
                column+=5
                first_price_cell = xl_rowcol_to_cell(row-number_of_lines-1, column)
                last_price_cell = xl_rowcol_to_cell(row-1, column)
                worksheet.write(row, column, "=SUM(%s:%s)"%(first_price_cell,last_price_cell),body_style)
                worksheet.write(row+1, column, p.notes if p.notes else "",body_style)
            column+=4
            
            #generating  lowest prices total   
            first_price_cell = xl_rowcol_to_cell(row-number_of_lines-1, column)
            last_price_cell = xl_rowcol_to_cell(row-1, column)
            worksheet.write(row, column, "=SUM(%s:%s)"%(first_price_cell,last_price_cell),body_style)
            column-=1
            row = 7
           
                 
            #Generate The EXCEL file
            workbook.close()
            data = open(temp_file.name, 'rb').read()
            return base64.b64encode(data)
            temp_file.close()
            
            
            
           
        
