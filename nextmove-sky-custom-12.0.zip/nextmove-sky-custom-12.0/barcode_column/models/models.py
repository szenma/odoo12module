# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.addons import decimal_precision as dp


class SaleOrder(models.Model):
    _inherit = 'sale.order'
    
    total_qty = fields.Float('Total Quantity', digits=dp.get_precision('Product Unit of Measure'), compute="_compute_total_qty")
    print_with_barcode = fields.Boolean("Print With Barcode")
    
    def _compute_total_qty(self):
        for rec in self:
            qty = 0
            for line in rec.order_line:
                qty += line.product_uom_qty
            rec.total_qty = qty
    

class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'
     
    total_qty = fields.Float('Total Quantity', digits=dp.get_precision('Product Unit of Measure'), compute="_compute_total_qty")
    show_barcode = fields.Boolean("Print With Barcode")
     
    def _compute_total_qty(self):
        for rec in self:
            qty = 0
            for line in rec.order_line:
                qty += line.product_uom_qty
            rec.total_qty = qty
     
            
class StockPicking(models.Model):
    _inherit = 'stock.picking'
    
    move_total_qty = fields.Float('Total Quantity', digits=dp.get_precision('Product Unit of Measure'), compute="_compute_total_qty")
    move_line_total_qty = fields.Float('Total Qty', digits=dp.get_precision('Product Unit of Measure'), compute="_compute_total_qty")
    show_barcode = fields.Boolean("Print With Barcode")
    
    def _compute_total_qty(self):
        for rec in self:
            qty = 0
            line_qty = 0
            for line in rec.move_lines:
                qty += line.product_uom_qty
            for line in rec.move_line_ids:
                line_qty += line.qty_done
            rec.move_total_qty = qty
            rec.move_line_total_qty = line_qty
     


class AccountInvoice(models.Model):
    _inherit = 'account.invoice'
     
    total_qty = fields.Float('Total Quantity',digits=dp.get_precision('Product Unit of Measure'), compute="_compute_total_qty")
    show_barcode = fields.Boolean("Print With Barcode") 
    
    def _compute_total_qty(self):
        for rec in self:
            qty = 0
            for line in rec.invoice_line_ids:
                pass
                qty += line.quantity
            rec.total_qty = qty
     

class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'
   
   
    
    @api.onchange('product_id')
    def _default_barcode(self):
        
        for line in self:
            #print(line.product_id.id)
            if line.product_id.id and line.product_id.barcode :
                self.env.cr.execute("SELECT * FROM product_barcode_multi WHERE product_id=%(ze)s and name=%(nam)s  limit 1",{'ze':line.product_id.id ,'nam':line.product_id.barcode}) 
                tra=self.env.cr.dictfetchall()
                if tra:
                    for yy in tra:
                        #print(yy['id'])
                        #return yy['name']
                        line.barcode=yy['id']
                  
        
    barcode = fields.Many2one('product.barcode.multi' , string='Barcode',domain="[('product_id','=',product_id)]")
    #barcode_ids = fields.One2many( 'product.barcode.multi' ,'product_id' , string='Barcode_ids')
    #working_user_ids = fields.Many2one('product.barcode.multi', string='Working user on this work order.')
    """@api.onchange('product_id')
    def get_selection_class(self):barcode_ids = fields.One2many('product.barcode.multi', string='Barcode',related="product_id.barcode_ids" domain="[('product_id','=',product_id)]" )
         active_id = self.env.context.get('product_id', []) or []
        classname = self.env['product.barcode.multi'].search(['product_id','=',active_id], limit=10)
        return [(x.name, x.name) for x in classname  ]
    @api.onchange('product_id')   
    def _onchange_barcode(self):
        self.barcode = product_id.barcode"""
    
    
    
class PurchaseOrderLine(models.Model):
    _inherit = 'purchase.order.line'
    
    barcode = fields.Char('Barcode', related="product_id.barcode")
    #barcode = fields.Many2one('product.barcode.multi' , string='Barcode',domain="[('product_id','=',product_id)]")
    
class AccountInvoiceLine(models.Model):
    _inherit = 'account.invoice.line'
    """@api.onchange('product_id')
    def _default_barcode(self):
        
        
        #self.env.cr.execute("SELECT * FROM account_invoice WHERE type=%(ze)s and id=%(te)s ",{'ze':'out_refund','te':1144 })
        self.env.cr.execute("SELECT * FROM account_invoice WHERE type=%(ze)s ",{'ze':'out_refund' })
        last_id =  self.env.cr.dictfetchall()
        for la in last_id: 
            #print(la['id'])  
            self.env.cr.execute("SELECT * FROM account_invoice_line WHERE invoice_id=%(ze)s  ",{'ze': la['id']})
            
            las=  self.env.cr.dictfetchall()
            for lu in las:
                self.env.cr.execute("select *  FROM sale_order_line_invoice_rel WHERE invoice_line_id=%(ze)s  ",{'ze':lu['id']})
                sale=  self.env.cr.dictfetchall()
                for sa in sale:
                    self.env.cr.execute("update sale_order_line set qty_invoiced=qty_delivered,invoice_status='invoiced' WHERE   id=%(ze)s  ",{'ze':sa['order_line_id']})
                    self.env.cr.execute("select order_id  FROM sale_order_line WHERE id=%(ze)s  ",{'ze':sa['order_line_id']})
                    order=  self.env.cr.dictfetchall()
                    for ord in order:
                        self.env.cr.execute("update sale_order set invoice_status='invoiced' WHERE    id=%(ze)s  ",{'ze':ord['order_id']})
                self.env.cr.execute("delete  FROM sale_order_line_invoice_rel WHERE invoice_line_id=%(ze)s  ",{'ze':lu['id']})"""
                               
    #barcode = fields.Char('Barcode', related="product_id.barcode")
    barcode = fields.Many2one('product.barcode.multi' ,string='Barcode' ,readonly=False,stored=True, compute="_compute_barcode",domain="[('product_id','=',product_id)]")
    @api.multi
    def _compute_barcode(self):
        
        for line in self:
            if line.sale_line_ids and line.product_id:
                line.barcode=line.sale_line_ids.barcode
            else:
                data = self.env['product.barcode.multi'].search([('name','=',line.product_id.barcode)]).id
                
                line.barcode=data
    
class StockMove(models.Model):
    _inherit = 'stock.move'
    
    #barcode = fields.Char('Barcode', related="sale_line_id.barcode")
    barcode = fields.Many2one('product.barcode.multi' , string='Barcode',domain="[('product_id','=',product_id)]")
    barcode = fields.Many2one('product.barcode.multi' ,string='Barcode' ,readonly=False,stored=True, compute="_compute_barcode",domain="[('product_id','=',product_id)]")
    @api.multi
    def _compute_barcode(self):
        
        for line in self:
            data = self.env['product.barcode.multi'].search([('name','=',line.product_id.barcode)]).id
            line.barcode=data            
class StockMoveLine(models.Model):
    _inherit = 'stock.move.line'
    @api.multi
    def get_data(self):
        data = self.env['sale.order.line'].search([])
        serialnumber = ""
        for rec in data:
            serialnumber += rec.x_serialnumber
        for record in self:
            record.x_serialnumber = serialnumber
    #barcode = fields.Char('Barcode', related="product_id.barcode")
    #barcode = fields.Many2one('product.barcode.multi' , related="move_id.sale_line_id.barcode", string='Barcode',domain="[('product_id','=',product_id)]")
    barcode = fields.Many2one('product.barcode.multi' ,string='Barcode' ,readonly=False,stored=True, compute="_compute_barcode",domain="[('product_id','=',product_id)]")
    @api.multi
    def _compute_barcode(self):
        
        for line in self:
            data = self.env['product.barcode.multi'].search([('name','=',line.product_id.barcode)]).id
            line.barcode=data
    
