Product Multiple Barcodes
=========================

This module allows to define multiple additional barcodes for products and to search products by additional barcodes and internal reference.

Changelog
---------

12.0.1.2.1 (2021-06-16)
***********************

* Changing of checking for uniqueness barcodes only by active products

12.0.1.2.0 (2020-06-24)
***********************

* Improvement of validate a barcode on unique

12.0.1.1.0 (2020-04-30)
***********************

* Added mandatory typing the name of additional barcode
* Added auto delete of additional barcodes when deleting products

12.0.1.0.0 (2019-07-12)
***********************

* Added field to define multiple additional barcodes of products
* Added the search products by additional barcodes and internal reference
