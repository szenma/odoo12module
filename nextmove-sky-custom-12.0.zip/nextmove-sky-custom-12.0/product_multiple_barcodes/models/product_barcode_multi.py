# Part of zen modules. See LICENSE file for full copyright and licensing details.

from odoo import models, fields


class ProductBarcodeMulti(models.Model):
    _name = 'product.barcode.multi'
    _description = 'Product Barcode Multi'

    name = fields.Char(
        'Barcode',
        required=True,
        
    )

    product_id = fields.Many2one(
        'product.product', 
        string='Product', 
        required=True,
        ondelete="cascade",
    )
    #current_dat = fields.Date(string='Date duplicate', readonly=True, compute='_get_current_dat')
    """def _get_current_dat(self):
        nam=[]
        for rec in self:
            nam.append(rec.name)
        self.env.cr.execute("SELECT * from product_product where   id!=%(mo)s  and barcode is not Null",{'mo':0 })
        products=self.env.cr.dictfetchall()
        #products=self.env['product.product'].search([('name', '!=', '')])
        for product in products:
            if product['barcode'] not in nam and product['barcode'] is not None:
                self.env.cr.execute("INSERT INTO product_barcode_multi (name,product_id)VALUES (%(name)s,%(product_id)s)",{'name':product['barcode'],'product_id':product['id']})"""  