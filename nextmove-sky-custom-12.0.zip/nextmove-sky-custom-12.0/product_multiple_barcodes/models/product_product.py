# Part of zen modules. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _
from odoo.osv import expression
from odoo.exceptions import UserError


class ProductProduct(models.Model):
    _inherit = 'product.product'

    barcode_ids = fields.One2many(
        'product.barcode.multi',
        'product_id',
        
        string='Additional Barcodes',
    )
    
    # THIS IS OVERRIDE SQL CONSTRAINTS.
    _sql_constraints = [
        ('barcode_uniq', 'check(1=1)', 'No error')
    ]
    '''@api.onchange('barcode')
    def _compute_barcode_ids(self):
        
        for pro in self:
            
            self.env.cr.execute("SELECT * FROM product_barcode_multi WHERE product_id=%(ze)s and name=%(nam)s  limit 1",{'ze':pro.id ,'nam':pro.barcode}) 
            tra=self.env.cr.dictfetchall()
            if not tra:
                self.env.cr.execute("INSERT INTO product_barcode_multi (name,product_id,create_uid ,create_date,write_uid,write_date)VALUES (%(name)s,%(product_id)s ,%(create_uid)s  ,%(create_date)s ,%(write_uid)s,%(write_date)s  )",{'name':pro.barcode,'product_id':pro.id,'create_uid':pro.create_uid ,'create_date':pro.create_date ,'write_uid':pro.write_uid ,'write_date':pro.write_date})
            self.env.cr.execute("SELECT * FROM product_barcode_multi WHERE product_id=%(ze)s ",{'ze':pro.id }) 
            tras=self.env.cr.dictfetchall()
            for product_barcode_mul in tras:
                pro.write({
                    
                   'barcode_ids': [(4, product_barcode_mul['id'])] ,
                })  '''

    @api.model
    def _name_search(self, name, args=None, operator='ilike', limit=100, name_get_uid=None):
        args = args or []
        domain = []
        if name:
            domain = ['|', '|', ('name', operator, name), ('default_code', operator, name),
                      '|', ('barcode', operator, name), ('barcode_ids', operator, name)]
        product_id = self._search(expression.AND([domain, args]),
                                  limit=limit, access_rights_uid=name_get_uid)
        return self.browse(product_id).name_get()

    @api.constrains('barcode', 'barcode_ids', 'active')
    def _check_unique_barcode(self):
        for product in self:
            barcode_names = []
            if product.barcode_ids:
                barcode_names = product.mapped('barcode_ids.name')
           
            if not barcode_names:
                continue
            products = self.env['product.product'].search([
                ('barcode', 'in', barcode_names),
                ('id', '!=', product.id),
                ('active', '=', True),
            ], limit=1)
            barcode_ids = self.env['product.barcode.multi'].search([
                ('name', 'in', barcode_names),
                ('product_id', '!=', product.id),
                ('product_id.active', '=', True),
            ], limit=1)
            if  barcode_ids or len(barcode_names) != len(set(barcode_names)):
                raise UserError(
                    _('The following barcode(s) were found in other active products: {0}.'
                      '\nNote that product barcodes should not repeat themselves both in '
                      '"Barcode" field and "Additional Barcodes" field.').format(
                            ", ".join(barcode_names)
                      )
                )
