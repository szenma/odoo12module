
# Part of zen modules. See LICENSE file for full copyright and licensing details.

from . import test_merp_product_barcode_multi
