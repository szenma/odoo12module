# Part of zen modules. See LICENSE file for full copyright and licensing details.

from . import multiply_barcode_wizard
