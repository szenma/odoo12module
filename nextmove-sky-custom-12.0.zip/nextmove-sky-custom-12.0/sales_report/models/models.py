# -*- coding: utf-8 -*-

from odoo import models, fields, api
import datetime

    
class SalesReport(models.Model):
    _name = "sales.report"
    _description = "Sales  Report"
    
    name = fields.Char("Name")



class SaleOrder(models.Model):
    _inherit = "sale.order"
    
    #daedline_date = fields.Datetime("Deadline Date")
    items = fields.Integer("Items", compute="_compute_items")
    #request_type_id = fields.Many2one("request.type", string="Request Type")
    first_line_description = fields.Text("Description", related="order_line.name")
    sending_date = fields.Datetime("Sending Date", readonly=True) #have to store the date time at which the status changed to send state
    #partner_division = fields.Many2one("partner.division", string="Partner Division", related="partner_id.division_id")
    total_sale = fields.Monetary("Total Sale",    store=True, readonly=True, compute="_compute_total_sale" , track_visibility='always', track_sequence=6)
    total_cost = fields.Monetary("Total Cost", store=True, readonly=True,compute="_compute_total_cost")
    rebate = fields.Monetary("Rebate",store=True, readonly=True, compute="_compute_rebate")
    sales_return = fields.Monetary("Sales Return",store=True, readonly=True, compute="_compute_sales_return")
    gp = fields.Monetary("GP",store=True,readonly=True, compute="_compute_gp")
    budget_expence = fields.Monetary("Budget Expence",store=True,readonly=True, compute="_compute_budget_expence")
    budget_np = fields.Monetary("Budget NP",store=True, readonly=True, compute="_compute_budget_np")
    #partner_division = fields.Monetary("Partner Division", compute="_compute_total_sale")
    current_dat = fields.Date(string='Invoice  Date', readonly=True, compute='_get_current_dat')
    gp_percentage = fields.Monetary("GP percentage",readonly=True, compute="_compute_gp_percentage")
    purchase_item = fields.Monetary("Purchase Item",readonly=True, compute="_compute_purchase_item")
    
    
    def _compute_gp_percentage(self):
        
        for rec in self:
            
            if rec.customer_type=='trading':
                if rec.gp!=0 and rec.total_cost!=0:
                    rec.gp_percentage=(rec.gp/rec.total_cost)*100
    def _compute_purchase_item(self):
        
        for rec in self:
            
            if rec.customer_type=='trading':
                products = self.env['purchase.order'].search([('origin', '=', rec.name),('state','in', ('done', 'purchase'))]) 
                total_cost = 0
                for product in products:
                    total_cost+=len(product.order_line)
                rec.purchase_item=total_cost
                    
    def _get_current_dat(self):
        for rec in self:
            retail=self.env['account.invoice'].search([('origin', '=', rec.name)],limit=1)
            if retail.date_invoice:
                rec.current_dat=retail.date_invoice 
        self.env.cr.execute("SELECT to_char(date_invoice, 'YYYY-MM') as revenue_date, sum(amount_untaxed) as revenue,partner_id FROM account_invoice WHERE type='out_refund' and date_invoice > date_trunc('month', CURRENT_DATE) - INTERVAL %(ye)s GROUP BY revenue_date,partner_id WINDOW w as (ORDER BY to_char(date_invoice, 'YYYY-MM')) ORDER BY revenue_date DESC",{'ye':'2 year' }) 
        tra=self.env.cr.dictfetchall()
        b=[]
        f=[]
        c=[]
        m=''
        n=0
        o=0
        z={}
        l=''
        for yy in tra:
            
            m=yy['revenue_date']
            n=yy['revenue']
            o=yy['partner_id']
            l=str(m)+str(c)
            z[l]=n
            self.env.cr.execute("SELECT  id,sales_return  from sale_order where to_char(confirmation_date, 'YYYY-MM')=%(revenue_date)s and partner_id=%(partner_id)s  and customer_type=%(customer_type)s and state in ('done','sale') and confirmation_date is not NULL and sales_return!=0 order by confirmation_date limit 1",{'revenue_date':m,'partner_id':o,'customer_type':'retail'})  
            sale=self.env.cr.dictfetchall()
            if sale:
                if  sale[0]['sales_return']!=z[l]:
                    self.env.cr.execute('UPDATE sale_order SET sales_return = %(si)s  WHERE id = %(partial_ids)s',
                    {'si': z[l],'partial_ids': sale[0]['id']}) 
                    z[l]=0
            else:
                self.env.cr.execute("SELECT  id,sales_return  from sale_order where to_char(confirmation_date, 'YYYY-MM')=%(revenue_date)s and partner_id=%(partner_id)s  and customer_type=%(customer_type)s and state in ('done','sale') and confirmation_date is not NULL  order by confirmation_date limit 1",{'revenue_date':m,'partner_id':o,'customer_type':'retail'})  
                sal=self.env.cr.dictfetchall()
                if sal:
                    self.env.cr.execute('UPDATE sale_order SET sales_return = %(si)s  WHERE id = %(partial_ids)s',
                    {'si': z[l],'partial_ids': sal[0]['id']})
                    z[l]=0
                else:
                    z[l]=z[l]+n
                    b.append(yy['revenue_date'])
                    f.append(yy['revenue'])
                    c.append(yy['partner_id'])
                    #self.env.cr.execute('UPDATE test SET si = %(si)s,ze = %(ze)s,tt = %(tt)s  WHERE id = %(partial_ids)s',
                    #{'si': b, 'ze': f,'tt': c, 'partial_ids':1}) 
                            
            
    def _compute_items(self):
        
        for rec in self:
            rec.items = len(rec.order_line)
            #total sale
            if rec.customer_type == 'retail':
                retail=self.env['account.invoice'].search([('origin', '=', rec.name),('customer_type','=', 'retail'),('state','in', ('open', 'paid'))])
                total_sale=retail.amount_untaxed/rec.currency_rate
                if total_sale!=rec.total_sale:
                    self.env.cr.execute('UPDATE sale_order SET total_sale = %(date)s  WHERE id = %(partial_ids)s',
                        {'date': total_sale,'partial_ids': rec.id})
            if rec.customer_type=='trading':
                total_sale=rec.amount_untaxed/rec.currency_rate
                if total_sale!=rec.total_sale:
                    self.env.cr.execute('UPDATE sale_order SET total_sale = %(date)s  WHERE id = %(partial_ids)s',
                        {'date': total_sale,'partial_ids': rec.id})
            #total cost
            if rec.customer_type == 'retail':
                    trading=self.env['stock.picking'].search([('origin', '=', rec.name),('state','=', 'done')],limit=1)
                    if trading:
                        products = self.env['account.move'].search([('ref', '=', trading.name),('state','=','posted')]) 
                        total_cost = 0
                        for product in products:
                            total_cost += product.amount
                        if total_cost!=rec.total_cost:
                            self.env.cr.execute('UPDATE sale_order SET total_cost = %(date)s  WHERE id = %(partial_ids)s',
                            {'date': total_cost,'partial_ids': rec.id})
            if rec.customer_type == 'trading':
                products = self.env['purchase.order'].search([('origin', '=', rec.name),('state','in', ('done', 'purchase'))]) 
                total_cost = 0
                for product in products:
                    if product.company_id.currency_id and product.currency_id: 
                        cur= self.env['res.currency']._get_conversion_rate(product.company_id.currency_id, product.currency_id, product.company_id, product.date_order)
                        total_cost += product.amount_untaxed/cur
                if total_cost!=rec.total_cost:
                    self.env.cr.execute('UPDATE sale_order SET total_cost = %(date)s  WHERE id = %(partial_ids)s',
                    {'date': total_cost,'partial_ids': rec.id})
                
            #rebate
            if rec.customer_type == 'retail':
                tradin=self.env['account.invoice'].search([('origin', '=', rec.name),('customer_type','=', 'retail'),('state','in', ('paid', 'open'))])
                if tradin:
                    products = self.env['account.payment'].search([('communication', '=', tradin.number),('state','=','posted')]) 
                    if products and products.amount!=rec.rebate:
                        #rec.rebate=products.amount
                        self.env.cr.execute('UPDATE sale_order SET rebate = %(date)s  WHERE id = %(partial_ids)s',
                            {'date': products.amount,'partial_ids': rec.id})
            if rec.customer_type=='trading':
                rec.rebate=0
        
            #sales return
         
            a={}
            c=0
            b=0
        
        for sip in self:
           
                
            #budget  expence
            c=0
            m={}
            n={}
            
            if sip.state in ('done','sale')  and sip.confirmation_date is not None :
                x=str(sip.confirmation_date).split()
                start_rec = datetime.datetime.strptime(x[0], "%Y-%m-%d")
                c=str(start_rec.strftime("%Y"))+str(start_rec.strftime("%m"))
                ye=str(start_rec.strftime("%Y"))
                mo=str(start_rec.strftime("%m"))
                if sip.customer_type =='retail' and sip.state in ('done','sale') and sip.confirmation_date is not None and sip.invoice_status =='invoiced' and c not in n:
                    n[c]=c
                    p='Retail Expenses'
                    self.env.cr.execute("SELECT * from crossovered_budget where  date_part('year', date_from)=%(ye)s and name=%(mo)s ",{'ye':ye,'mo':p })
                    tra=self.env.cr.dictfetchall()
                    if tra:
                        trading=self.env['crossovered.budget.lines'].search([('crossovered_budget_id','=', tra[0]['id'])])
                        xt= trading.planned_amount/12
                        pp=0
                        if xt!=sip.budget_expence:
                            self.env.cr.execute("SELECT id from sale_order where customer_type='retail' and date_part('year', confirmation_date)=%(ye)s and date_part('month', confirmation_date)=%(mo)s and budget_expence!=%(pe)s",{'ye':ye,'mo':mo,'pe': pp })
                            results = self.env.cr.dictfetchall()
                            if not results:
                                self.env.cr.execute('UPDATE sale_order SET budget_expence = %(date)s  WHERE  id = %(partial_ids)s',
                                {'date': xt,'partial_ids': sip.id})
                            else:
                                self.env.cr.execute('UPDATE sale_order SET budget_expence = %(date)s  WHERE id = %(partial_ids)s',
                                {'date': xt,'partial_ids': results[0]['id']})
                if sip.customer_type == 'trading' and sip.state in ('done','sale')  and sip.confirmation_date is not None   and c not in m:
                    m[c]=c
                    p='Trading Expenses'
                    self.env.cr.execute("SELECT  * FROM crossovered_budget where  date_part('year', date_from)=%(ye)s and name=%(mo)s ",{'ye':ye,'mo':p })
                    tra=self.env.cr.dictfetchall()
                    #tra=self.env['crossovered.budget'].search([('name','=', p)])
                    if tra:
                        trading=self.env['crossovered.budget.lines'].search([('crossovered_budget_id','=', tra[0]['id'])])
                        xt= trading.planned_amount/12
                        pp=0
                        if xt!=sip.budget_expence:
                            self.env.cr.execute("SELECT id from sale_order where customer_type='trading' and date_part('year', confirmation_date)=%(ye)s and date_part('month', confirmation_date)=%(mo)s and budget_expence!=%(pe)s",{'ye':ye,'mo':mo,'pe': pp })
                            results = self.env.cr.dictfetchall()
                            if not results:
                                self.env.cr.execute('UPDATE sale_order SET budget_expence = %(date)s  WHERE id = %(partial_ids)s',
                                {'date': xt,'partial_ids': sip.id})
                            else:
                                self.env.cr.execute('UPDATE sale_order SET budget_expence = %(date)s  WHERE id = %(partial_ids)s',
                                {'date': xt,'partial_ids': results[0]['id']})
               
            gp = (sip.total_sale-sip.total_cost)-(sip.rebate+sip.sales_return) 
            if gp!=sip.gp:
                self.env.cr.execute('UPDATE sale_order SET gp = %(date)s  WHERE id = %(partial_ids)s',
                {'date': gp,'partial_ids': sip.id})
            budget_np = sip.gp-sip.budget_expence
            if budget_np!=sip.budget_np:
                self.env.cr.execute('UPDATE sale_order SET budget_np = %(date)s  WHERE id = %(partial_ids)s',
                {'date': budget_np,'partial_ids': sip.id}) 
            
            
    def _compute_gp(self):
        for rec in self:
            gp = (rec.total_sale-rec.total_cost)-(rec.rebate+rec.sales_return) 
            self.env.cr.execute('UPDATE sale_order SET gp = %(date)s  WHERE id = %(partial_ids)s',
            {'date': gp,'partial_ids': rec.id})
            

    def _compute_budget_np(self):
        for rec in self:
            budget_np = rec.gp-rec.budget_expence 
            self.env.cr.execute('UPDATE sale_order SET budget_np = %(date)s  WHERE id = %(partial_ids)s',
            {'date': budget_np,'partial_ids': rec.id})

    def _compute_budget_expence(self):
        c=0
        b={}
        a={}
        m=[]
        n=[]
        for rec in self:
            if rec.state in ('done','sale')  and rec.confirmation_date is not None :
                x=str(rec.confirmation_date).split()
                start_rec = datetime.datetime.strptime(x[0], "%Y-%m-%d")
                c=str(start_rec.strftime("%Y"))+str(start_rec.strftime("%m"))
                
                if rec.customer_type == 'retail' and rec.state in ('done','sale')  and rec.confirmation_date is not None and rec.invoice_status =='invoiced'   and c not in a:
                    a[c]=c
                    m.append(rec.id)
                    p='Retail Expenses'
                    tra=self.env['crossovered.budget'].search([('name','=', p)])
                    trading=self.env['crossovered.budget.lines'].search([('crossovered_budget_id','=', tra.id)])
                    xt= trading.planned_amount/12
                    rec.budget_expence = xt
                    
                if rec.customer_type == 'trading' and rec.state in ('done','sale')  and rec.confirmation_date is not None   and c not in b:
                    b[c]=c
                    n.append(rec.id)
                    p='Trading Expenses'
                    tra=self.env['crossovered.budget'].search([('name','=', p)])
                    trading=self.env['crossovered.budget.lines'].search([('crossovered_budget_id','=', tra.id)])
                    xt= trading.planned_amount/12
                    rec.budget_expence = xt
                
            
        
        
    @api.depends('items')
    def _compute_sales_return(self):
        a={}
        c=0
        b=0
        for rec in self:
            x=str(rec.confirmation_date).split()
            c=x[0]
            if rec.customer_type == 'retail' and rec.state in ('done','sale')  and rec.confirmation_date is not None and c not in a:
                p=str(rec.confirmation_date).split()
                p = datetime.datetime.strptime(p[0], "%Y-%m-%d")
                end_date = p + datetime.timedelta(days=1)
                trading=self.env['account.invoice'].search([('type', '=','out_refund'),('create_date', '>=',p),('create_date', '<',end_date) ])
                if trading:
                    total_cost = 0
                    for trad in trading:
                        
                        total_cost += trad.residual
                        y=str(trad.create_date).split()
                    if y[0]==x[0] and c not in a:
                        #rec.sales_return=total_cost
                        self.env.cr.execute('UPDATE sale_order SET sales_return = %(date)s  WHERE id = %(partial_ids)s',
                        {'date': total_cost,'partial_ids': rec.id})
                        a[x[0]]=x[0]
                        b=y[0]
                              
            elif rec.customer_type=='trading':
                rec.sales_return=0
    @api.depends('items')            
    def _compute_rebate(self):
        for rec in self:
            if rec.customer_type == 'retail':
                
                trading=self.env['account.invoice'].search([('origin', '=', rec.name),('customer_type','=', 'retail'),('state','in', ('paid', 'open'))])
                products = self.env['account.payment'].search([('communication', '=', trading.number),('state','=','posted')]) 
                #rec.rebate=products.amount
                self.env.cr.execute('UPDATE sale_order SET rebate = %(date)s  WHERE id = %(partial_ids)s',
                    {'date': products.amount,'partial_ids': rec.id})
            elif rec.customer_type=='trading':
                rec.rebate=0
                
    @api.depends('items')
    def _compute_total_sale(self):
        
        for rec in self:
            if rec.customer_type == 'retail':
                retail=self.env['account.invoice'].search([('origin', '=', rec.name),('customer_type','=', 'retail')])
                #total_sale=retail.amount_untaxed/rec.currency_rate
                #self.env.cr.execute('UPDATE sale_order SET total_sale = %(date)s  WHERE id = %(partial_ids)s',
                #    {'date': total_sale,'partial_ids': rec.id})
            if rec.customer_type=='trading':
                total_sale=rec.amount_untaxed/rec.currency_rate
                self.env.cr.execute('UPDATE sale_order SET total_sale = %(date)s  WHERE id = %(partial_ids)s',
                    {'date': total_sale,'partial_ids': rec.id})
                #rec.total_sale=rec.amount_untaxed/rec.currency_rate
                
              
    def _compute_total_cost(self):
        for rec in self:
            if rec.state in ('done','sale'):
                if rec.customer_type == 'retail':
                    trading=self.env['stock.picking'].search([('origin', '=', rec.name),('state','=', 'done')])
                    products = self.env['account.move'].search([('ref', '=', trading.name),('state','=','posted')]) 
                    total_cost = 0
                    for product in products:
                        total_cost += product.amount
                    rec.total_cost = total_cost
                    self.env.cr.execute('UPDATE sale_order SET total_cost = %(date)s  WHERE id = %(partial_ids)s',
                    {'date': total_cost,'partial_ids': rec.id})
                if rec.customer_type == 'trading':
                    products = self.env['purchase.order'].search([('origin', '=', rec.name),('state','in', ('done', 'purchase'))]) 
                    #cur=self.env['res.currency.rate'].search([('currency_id', '=', 2 )])
                    total_cost = 0
                    for product in products:
                        if product.company_id.currency_id and product.currency_id: 
                            cur= self.env['res.currency']._get_conversion_rate(product.company_id.currency_id, product.currency_id, product.company_id, product.date_order)
                            total_cost += product.amount_untaxed/cur
                    rec.total_cost = total_cost
                    self.env.cr.execute('UPDATE sale_order SET total_cost = %(date)s  WHERE id = %(partial_ids)s',
                    {'date': total_cost,'partial_ids': rec.id})
