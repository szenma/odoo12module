# -*- coding: utf-8 -*-
{
    'name': "sales_report",
    'summary': """
   Sales  Report.
""",
    'description': """
    report jerald.
    """,
    'author': "",
    'website': "",
    'category': 'SKY',
    'version': '12.0.1.5',
    'depends': ['base','sale','retail_trading_workflow','comparison_sheet'],
    'data': [
        
        'views/views.xml',
    ],
}