# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.tests.common import Form
from odoo.exceptions import UserError
import base64

FILE_TYPE_DICT = {
    'csv': 'text/csv',
    'xls':'application/vnd.ms-excel',
    'xlsx':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
}

class ImportPurchaseOrderLine(models.TransientModel):
    _name = "import.purchaseorder.line"
    _description = "Import Purchase Order Line"
    
    file = fields.Binary(string='File')
    file_name = fields.Char('File Name')
    is_header = fields.Boolean(string='The first line is the header?', default=True)
    message = fields.Text('Message', readonly=True)
    quantity_message = fields.Text('Message', readonly=True)
    price_message = fields.Text('Message', readonly=True)
    
    def import_purchaseorder_line(self):
        file_type = FILE_TYPE_DICT.get(self.file_name.split('.')[-1].lower(), False)
        if not file_type:
            raise UserError("Oops, the format of your file is not compatible. Kindly try importing formats of XLS, XLSX or CSV only")
        
        import_wizard = self.env['base_import.import'].create({
            'res_model': 'import.purchaseorder.line',
            'file': base64.b64decode(self.file),
            'file_name': self.file_name,
            'file_type': file_type})
        lines = import_wizard._read_file({'quoting':'"',
                                        'separator':','})
        if self.is_header:
            next(lines)
        
        not_exist_products = []
        not_exist_quantities = []
        not_exist_price = []
        
        products = self.env['product.product'].search([])
        products_dict = {product.barcode : product for product in  products}
        purchase_order_obj = self.env['purchase.order'].browse(self._context.get('active_id', False))
        with Form(purchase_order_obj, view='purchase.purchase_order_form') as purchase_order:
                for line in lines:
                    if not products_dict.get(line[0], False):
                        not_exist_products.append(line[0])
                        continue
                    elif line[1] == '0' or line[1]=='':
                        not_exist_quantities.append(line[0])
                        continue
                    elif line[2] == '0' or line[2]=='':
                        not_exist_price.append(line[0])
                        continue
                    if line[3] != '0' and line[3] !='':
                        analytic_account = self.env["account.analytic.account"].search([('name','ilike',line[3])])
                    with purchase_order.order_line.new() as order_line:
                         order_line.product_id = products_dict.get(line[0], False)
                         order_line.product_qty = line[1]
                         order_line.price_unit = line[2]
                         if analytic_account:
                            order_line.account_analytic_id = analytic_account
                purchase_order_id = purchase_order.save()
        self.message = ' , '.join(not_exist_products)
        self.quantity_message = ' , '.join(not_exist_quantities)
        self.price_message = ' , '.join(not_exist_price)
        if self.message or self.quantity_message or self.price_message:
            view = self.env.ref('pol_import.import_purchaserder_line_message_wizard')
            return {
                 "type": "ir.actions.act_window",
                "res_model": "import.purchaseorder.line",
                "views": [[view.id, "form"]],
                
                "res_id": self.id ,
                "target": "new",
                }

                
            
