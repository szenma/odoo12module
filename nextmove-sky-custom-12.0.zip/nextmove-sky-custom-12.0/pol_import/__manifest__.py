# -*- coding: utf-8 -*-
{
    'name': "SW - POL Import",
    'summary': """
    Import the Purchase Order Line from excel.
       """,
    'description': """
    Import the Purchase Order Line from excel.
    """,
    'author': "Smart Way Business Solutions",
    'website': "https://www.smartway.co",
    'category': 'SKY',
    'version': '12.0.1.1',
    'depends': ['base','purchase'],
    'data': [
        'wizard/import_purchase_order_line.xml',
        'views/purchase_order_view.xml',
        
    ],
}