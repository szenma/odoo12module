# -*- coding: utf-8 -*-
{
    'name': "Sw - Update Journal Items Accounts",
    'summary': """
       """,
    'description': """
    """,
    'author': "Smart Way Business Solutions",
    'website': "https://www.smartway.co",
    'category': 'SKY',
     'version': '12.0.0.0',
    'depends': ['base','sale','hr','stock'],
    'data': [
       "wizard/update_journal_items.xml"
    ],
}