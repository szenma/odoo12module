# -*- coding: utf-8 -*-

from . import update_journal_items
