# -*- coding: utf-8 -*-

from odoo import models, fields, api

class UpdateJournalItemAccount(models.TransientModel):
    _name = "update.journal.item.account"
    _description = "Update Journal Item Account"
    
    def _update_customer_move_line(self):
        move_lines = self.env["account.move.line"].search([('journal_id','=',1),
                                                            ('product_id','!=',False)
                                                ])
        for mve in move_lines:
            income_account = mve.product_id.property_account_income_id
            self._cr.execute("""update account_move_line aml set account_id = %s where aml.id = %s""",(income_account.id,mve.id))
    
    def _update_vendor_move_line(self):
        move_lines = self.env["account.move.line"].search([('journal_id','=',2),
                                                   ('product_id','!=',False)
                                                   ])
        for mve in move_lines:
            exp_account = mve.product_id.property_account_expense_id
            self._cr.execute("""update account_move_line aml set account_id = %s where aml.id = %s""",(exp_account.id,mve.id))
    
    def _update_stock_move_lines(self):
       
        move_lines = self.env["account.move.line"].search([('journal_id','=',8),
                                                           ('account_id','in',[49,51])
                                                           ])
        
        for mve in move_lines.filtered(lambda l:l.account_id.id == 49):
            input_account = mve.product_id.categ_id.property_stock_account_input_categ_id.id
            self._cr.execute("""update account_move_line aml set account_id = %s where aml.id = %s""",(input_account,mve.id))
        for mve in move_lines.filtered(lambda l:l.account_id.id == 51):
            output_account = mve.product_id.categ_id.property_stock_account_output_categ_id.id
            self._cr.execute("""update account_move_line aml set account_id = %s where aml.id = %s""",(output_account,mve.id))
            
            
             
            
        
    
    def _update_products_account(self):
        products = self.env['product.product'].search([])
        for product in products:
            product.property_account_income_id = product.categ_id.property_account_income_categ_id
            product.property_account_expense_id = product.categ_id.property_account_expense_categ_id
        
        
    def update_products_move_lines(self):
        self._update_products_account()
        self._update_stock_move_lines()
        self._update_vendor_move_line()
        self._update_customer_move_line()
        self.env["account.move.line"].invalidate_cache()
        
        
