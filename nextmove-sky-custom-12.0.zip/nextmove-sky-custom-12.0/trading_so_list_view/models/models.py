# -*- coding: utf-8 -*-

from odoo import models, fields, api


    
class PartnerDivision(models.Model):
    _name = "partner.division"
    _description = "Partner Division"
    
    name = fields.Char("Name")

class ResPartner(models.Model):
    _inherit = 'res.partner'
    
    division_id = fields.Many2one("partner.division", "Division")


class SaleOrder(models.Model):
    _inherit = "sale.order"
    
    daedline_date = fields.Datetime("Deadline Date")
    line_items = fields.Integer("Line Items", compute="_compute_line_items")
    request_type_id = fields.Many2one("request.type", string="Request Type")
    first_line_description = fields.Text("First Line Description", related="order_line.name")
    sending_date = fields.Datetime("Sending Date", readonly=True) #have to store the date time at which the status changed to send state
    partner_division = fields.Many2one("partner.division", string="Partner Division", related="partner_id.division_id")
    total_rfq_cost = fields.Monetary("Total RFQ Cost")
    remarks = fields.Char("Remarks")
    rfq_old_ref = fields.Char("RFQ Old Ref")
    
    @api.model_create_multi
    @api.returns('self', lambda value: value.id)
    def create(self,vals):
        for val in vals:
            if val.get('state',False) and val['state'] == "sent":
                val["sending_date"] = fields.Datetime.now()
        return super(SaleOrder, self).create(vals) 
                
    @api.multi
    def write(self, vals):
        if vals.get('state',False) and vals["state"] == "sent":
            vals["sending_date"] = fields.Datetime.now()
        
        return super(SaleOrder, self).write(vals)
    
    
    def _compute_line_items(self):
        for rec in self:
            rec.line_items = len(rec.order_line)
    


class RequestType(models.Model):
    _name = "request.type"
    _description = "Request Type"
    
    name = fields.Char("Name")
