# -*- coding: utf-8 -*-
{
    'name': "SW - Trading SO List View",
    'summary': """
    SO list view extra columns.
""",
    'description': """
    SO list view extra columns.
    """,
    'author': "Smart Way Business Solutions",
    'website': "https://www.smartway.co",
    'category': 'SKY',
    'version': '12.0.1.4',
    'depends': ['base','sale','retail_trading_workflow','comparison_sheet'],
    'data': [
        'security/ir.model.access.csv',
        'views/views.xml',
    ],
}
