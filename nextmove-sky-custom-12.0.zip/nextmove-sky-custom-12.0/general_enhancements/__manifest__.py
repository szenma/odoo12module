# -*- coding: utf-8 -*-
{
    'name': "SW - General Enhancement",
    'summary': """
    Barcode Search & Bank Account Currency
      """,
    'description': """
    Barcode Search & Bank Account Currency
    """,
    'author': "Smart Way Business Solutions",
    'website': "https://www.smartway-jo.com",
    'category': 'SKY',
    'version': '12.0.1.2',
    'depends': ['base','account','product','stock'],
    'data': [
        "views/views.xml"
    ],
}
