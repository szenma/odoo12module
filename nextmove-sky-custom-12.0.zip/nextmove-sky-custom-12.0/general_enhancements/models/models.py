# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.osv import expression


class AccountInvoice(models.Model):
    _inherit = 'account.invoice'
    
    @api.model_create_multi
    @api.returns('self', lambda value: value.id)
    def create(self, vals):
        res = super(AccountInvoice, self).create(vals)
        for rec in res.filtered(lambda x:(x.type in ('out_invoice', 'in_refund') and x.company_id)):
            rec.partner_bank_id = rec._get_partner_bank_id(rec.company_id.id)
        return res
    
    def _get_partner_bank_id(self, company_id):
        original_bank = super(AccountInvoice, self)._get_partner_bank_id(company_id)
        company = self.env['res.company'].browse(company_id)
        currency = self.currency_id if self.currency_id else self._default_currency()
        if company.partner_id and currency and currency.name=="USD":
            bank = self.env['res.partner.bank'].search([
                ('partner_id', '=', company.partner_id.id), ('company_id', '=', company.id),
                ("currency_id",'=',currency.id)
            ], limit=1)
            if not bank:
                bank = self.env['res.partner.bank'].search([
                    ('partner_id', '=', company.partner_id.id), ('company_id', '=', False),
                    ("currency_id",'=',self.currency_id.id)
                ], limit=1)
            if bank:
                return bank
            else:
                return original_bank
        else: 
            return original_bank
        
         
    
    @api.onchange("currency_id","company_id")
    def on_comppany_currency_change(self):
        for rec in self.filtered(lambda x:(x.type in ('out_invoice', 'in_refund') and x.company_id and x.currency_id)):
            bank = rec._get_partner_bank_id(rec.company_id.id)
            rec.partner_bank_id = bank.id
            


class ProductProduct(models.Model):
    _inherit = "product.product"
    
    
    
    @api.model
    def name_search(self, name, args=None, operator='ilike', limit=100):
        res = super(ProductProduct, self).name_search( name, args, operator, limit)
        if not args:
            args = []
        if name:
            products = [x[0] for x in res]
            product_ids = self._search(expression.AND([args, [('barcode', 'ilike', name), ('id', 'not in', products)]]), limit=limit)
            res+=self.browse(product_ids).name_get()
        return res
    
    @api.multi
    def name_get(self):
       res = []
       if self._context.get("show_product_barcode",False):
           for product in self:
               name = ""
               if product.default_code and product.barcode:
                   name += "[%s] [%s] " %(product.barcode  , product.default_code)
               elif product.default_code or product.barcode:
                   name += "[%s%s] " %(product.barcode if product.barcode else "" , product.default_code if product.default_code else "")
               name  += product.name
               res.append((product.id, name))
           return res
       else :
           return super(ProductProduct, self).name_get()
            

    


class StockQuant(models.Model):
    _inherit = "stock.quant"
    
    
    product_categ_id = fields.Many2one('product.category', 'Product Category',related="product_id.categ_id", store=True)
    
    
class StockMoveLine(models.Model):
    _inherit = "stock.move.line"
    
    
    partner_id = fields.Many2one("res.partner",string="Partner", related="picking_id.partner_id")


class AP(models.Model):
    _inherit = "account.payment"
    
    
    def _get_move_vals(self ,journal=None):
        vals = super(AP, self)._get_move_vals(journal)
        if self._context.get("invoice_date",False):
            vals["date"] = self._context.get("invoice_date")
        return vals
        
        
    


    

         