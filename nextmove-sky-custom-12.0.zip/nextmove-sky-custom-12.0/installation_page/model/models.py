# -*- coding: utf-8 -*-
from odoo import models, fields, api, _

class InstallationPage(models.Model):
    _name = "installation.page"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'id desc'
    
    name = fields.Char('Number', readonly=True, default='New', required=True)
    partner_id = fields.Many2one('res.partner','Seller',required=True,track_visibility='always')
    end_user = fields.Char("End User", track_visibility='always', required=True)
    request_date = fields.Date('Request Date',required=True,track_visibility='always')
    installation_date = fields.Date('Installation Date',required=True,track_visibility='always')
    scheduled_installation_date = fields.Datetime('Scheduled Installation Date',required=True,track_visibility='always')
    technician_id = fields.Many2one('hr.employee','Technician',required=True,track_visibility='always')
    location = fields.Char("Location", required=True, track_visibility='always')
    installation_product_lines = fields.One2many("installation.product.line",'installation_id', string="Installation Lines")
    sky_reference = fields.Char("Sky Reference", track_visibility='always', required=True)
    note = fields.Char("Note", track_visibility='always')
    
    state = fields.Selection([('draft','Draft'),
                              ('confirmed','Confirmed'),
                              ('in_progress','In Progress'),
                              ('done','Done'),
                              ('cancel','Canceled')],default='draft',required=True,track_visibility='always')
    
    @api.model_create_multi
    @api.returns('self', lambda value: value.id)
    def create(self, vals):
        next_by_code = self.env['ir.sequence'].next_by_code
        for val in vals: val['name'] = next_by_code('installation.page')
        return super(InstallationPage, self).create(vals)
    
    
    @api.multi
    def action_draft(self):
        self.write({'state':'draft'})
        
    @api.multi
    def action_confirmed(self):
        self.write({'state':'confirmed'})
        
        
    @api.multi
    def action_in_progress(self):
        self.write({'state':'in_progress'})
        
    @api.multi
    def action_done(self):
        self.write({'state':'done'})
        
    @api.multi
    def action_cancel(self):
        self.write({'state':'cancel'})
        
        
    def create_activity(self):
        acivity_vals= {'res_model':self._name,
               'res_model_id':self.env.ref('sale.model_sale_order').id,
               'res_id':self.id,
               'activity_type_id':self.env.ref('mail.mail_activity_data_todo').id,
               'summary':', '.join([self.name,self.partner_id.name,str(self.amount_total) + str(self.currency_id.symbol)])
               }
        activity_obj = self.env['mail.activity']
        is_one_approval_needed = True if self.env.user.company_id.quotaions_approvals == "one_approval_needed" else False
        users_to_notify = self.env.user.company_id.users_to_be_notified_ids.ids
        if not is_one_approval_needed:
            for user in self.approvals_group_ids.mapped('user_id'):
                acivity_vals['user_id'] = user.id
                activity_obj.create(acivity_vals).action_close_dialog()
        else:
            for user in self.approvals_group_ids.mapped('user_id'):
                if user.id in users_to_notify:
                    acivity_vals['user_id'] = user.id
                    activity_obj.create(acivity_vals).action_close_dialog()
        
        
        
class InstallationPageLine(models.Model):
    _name = "installation.product.line"
    _description = "Installation Product Line"
    
    product_id = fields.Many2one("product.product", String="Product",track_visibility='always', required=True)
    quantity = fields.Integer("Quantity",track_visibility='always', required=True)
    installation_id = fields.Many2one("installation.page")
