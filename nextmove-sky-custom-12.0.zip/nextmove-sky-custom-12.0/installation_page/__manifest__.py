# -*- coding: utf-8 -*-
{
    'name': "SW - Installation Page",
    'summary': """Manage Installation Requests & Schedule
        """,
    'description': """
                 """,
    'author': "Smart Way Business Solutions",
    'website': "https://www.smartway-jo.com",
    'category': 'SKY',
    'version': '12.0.1.0',
    'depends': ['base', 'sale', 'hr', 'sales_team'],
    'data': ['views/views.xml',
             'security/ir.model.access.csv',
             'data/data.xml'],
}
