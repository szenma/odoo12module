# -*- coding: utf-8 -*-
{
    'name': "zen - Sales Order Form",
    'summary': """
    Sales Order Form
     """,
    'description': """
    Sales Order Form the report can be generated in PDF or Excel format.
    """,
    'author': "",
    'website': "",
    'category': 'Accounting',
    'version': '12.0.1.1',
    'depends': ['base','stock', 'account','stock_account','product'],
    'data': [
        'data/report_paperformat_data.xml',
        'template/salesorderform_layout.xml',
        'template/salesorderform_report_template.xml',
        'views/views.xml',
        'template/salesorderform_report_template.xml',
        
    ],
}