# -*- coding: utf-8 -*-
from datetime import datetime

from odoo import api, fields, models, _
import tempfile
import base64
import xlsxwriter
import babel.dates
import io  
from xlsxwriter.utility import xl_rowcol_to_cell
import json

    
class SalesorderformReport(models.TransientModel):
    _name = "salesorderform.report"
    _description = "Sales Order Form"
    categ_id = fields.Many2many('product.category', string='Product Category')
    partner_id = fields.Many2one("res.partner", string="Customer", required=True)
    from_date = fields.Date("Date",default=datetime.today().strftime('%Y-%m-%d'))
    #to_date = fields.Date("To Date",required=True)
    file = fields.Binary("File")
    file_name = fields.Char("File Name")
    print_customer_code = fields.Boolean("print  customer code")  
    print_quantity_onhand = fields.Boolean("print quantity  on   hand ")  
    print_retail_price = fields.Boolean("print retail price  ")  
    quantity_onhand = fields.Float("qunity    on  hand  ")  
    #list_price = fields.Float('Sales Price', default=1.0,digits=dp.get_precision('Product Price'),help="Price at which the product is sold to customers.")
    
        
    def _get_data(self):
        invoices_data = {}
        thislist = []
        thislis = []
        thi = []
        for x in self.categ_id:
            thislist.append(str(x.id))
            
        for x in thislist:
            thislis.append(int(x))
            
        
        
        """self.env.cr.execute('UPDATE test SET le = %(date)s,ze = %(ze)s  WHERE id = %(partial_ids)s',
        {'date': str(thislist),'ze': '57775','partial_ids': 1}) 
        self.env.cr.execute('UPDATE test SET le = %(date)s,ze = %(ze)s  WHERE id = %(partial_ids)s',
        {'date': 'yyyyyyyyyyyy','ze': '57775','partial_ids': 2}) 
        state_domain = [('categ_id','in',thislist)] """
        
         
        
        order_by = 'categ_id DESC'
        invoices = self.env["product.template"].search([('categ_id','in',thislis),("qty_available",">",self.quantity_onhand)],limit=None, order=order_by)
        thislist = []
        for invoice in invoices:
            thislist.append(str(invoice.list_price))  
            
                
            invoices_data[invoice.id]={"itemcode": invoice.default_code  }
            invoices_data[invoice.id]={"barcode" : invoice.barcode if invoice.barcode else "" }
            invoices_data[invoice.id]={"customer_itemcode":invoice.almeera_itemcode if invoice.almeera_itemcode else invoice.lulu_itemcode }
            invoices_data[invoice.id]={"categ_id" : invoice.categ_id  if invoice.categ_id else "" }
            invoices_data[invoice.id]={"description" : invoice.description  if invoice.description else "" }
            invoices_data[invoice.id]={"retail_price" : invoice.list_price  if invoice.list_price else "" }
            invoices_data[invoice.id]={"stock_qty" : invoice.qty_available  if invoice.qty_available else "" }
            invoices_data[invoice.id]={"order_qty" : "" }
            
            
            
        for invoice , invoice_info  in invoices_data.items():
            for inv , invoice_in  in invoice_info.items():
                thi.append(str(invoice_in))
       
        
        return {
             
             "partner":self.partner_id.display_name,
             "from_date":self.from_date,
            
            "invoices_data":invoices
           
            
            }
        
    def generate_excel_report(self):
        invoices_data = {}
        thislist = []
        thislis = []
        thi = []
        for x in self.categ_id:
            thislist.append(str(x.id))
            
        for x in thislist:
            thislis.append(int(x))
        data = self._get_data()
        invoices_data = data.get("invoices_data")
       
        temp_file = tempfile.NamedTemporaryFile(suffix=".xlsx")
        workbook = xlsxwriter.Workbook(temp_file.name)
        money_format = workbook.add_format({'num_format': '#,###,###.##'}) 
        ref=''
        if self.partner_id.ref:
            ref=self.partner_id.ref
        else:
            ref=''

        header_style = workbook.add_format({'bold': True,'font_name':'Calibri Light','align': 'center','bg_color':'#d3d3d3'})
        label_style = workbook.add_format({'bold': True,'font_name':'Calibri Light','bg_color':'#d3d3d3'})
        worksheet = workbook.add_worksheet('Sheet 1')
        worksheet.merge_range(0,0,0,6,self.env.user.company_id.name,header_style)
        worksheet.merge_range(1, 0, 1, 6, "Sales Order Form",header_style)
        worksheet.merge_range(2,0,2,6,self.partner_id.display_name+ ' ' + ref,header_style)
        worksheet.write(3,0,"Date")
        
        worksheet.write(3,1,str(self.from_date))
       
        
        worksheet.write(4,0,"Itemcode",label_style)
        worksheet.write(4,1,"Barcode",label_style)
        if self.print_customer_code:
            worksheet.write(4,2,"Customer Item Code",label_style)
        worksheet.write(4,3,"Product  Category",label_style)
        worksheet.write(4,4,"Decription",label_style)
        if self.print_retail_price:
            worksheet.write(4,5,"Retail Price",label_style)
        if self.print_quantity_onhand:
            worksheet.write(4,6,"Stock Quantity",label_style)
        worksheet.write(4,7,"Order Quantity",label_style)
        thisl=[]
        row = 5
        invoices = self.env["product.template"].search([('categ_id','in',thislis)])
        for invoice in invoices:
            if invoice.qty_available > self.quantity_onhand :
                thisl.append(str(invoice.default_code))
                if invoice.almeera_itemcode and not self.partner_id.display_name.find("Al Meera"):
                    cust_cod=invoice.almeera_itemcode
                elif invoice.lulu_itemcode and not self.partner_id.display_name.find("Lulu"):
                    cust_cod=invoice.lulu_itemcode
                else:
                    cust_cod=''
                
                worksheet.write(row,0,invoice.default_code  )
                worksheet.write(row,1,invoice.barcode  )
                if self.print_customer_code:
                    worksheet.write(row,2, cust_cod )
                worksheet.write(row,3,invoice.categ_id.name )
                worksheet.write(row,4,invoice.name )
                if self.print_retail_price:
                    worksheet.write(row,5, invoice.list_price )
                if self.print_quantity_onhand:
                    worksheet.write(row,6,invoice.qty_available )
                worksheet.write(row,7,'')
                       
                row+=1
       
        
        row+=4
        
       
        
        workbook.close()
        data = open(temp_file.name, 'rb').read()
        self.file =  base64.b64encode(data)
        self.file_name = "salesorderform.xlsx"
        action =  {
            'type': 'ir.actions.act_url',
            'url': '/web/binary/download_xls_document_salesorderform_report/?model=salesorderform.report&id=%s' % (self.id),
            'target': 'self',
        }
        return action
        
    
    
    def generate_pdf_report(self):
        data = self._get_data()
        return self.env.ref("salesorderform_report.salesorderform_report").report_action([], data=data)
        

        
        
