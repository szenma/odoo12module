# -*- coding: utf-8 -*-

from . import salesorderform_report