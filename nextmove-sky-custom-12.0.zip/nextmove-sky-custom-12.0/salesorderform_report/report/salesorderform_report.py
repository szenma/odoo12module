#-*- coding:utf-8 -*-

from odoo import api, fields, models, _
import time

class SalesOrderFormReport(models.AbstractModel):
    _name = 'report.salesorderform_report.invoice_salesorderform_report'
    _description = "Sales Order Form"
    
    @api.model
    def _get_report_values(self, docids, data=None):
        return {
             'doc_ids': docids,
            'doc_model': 'product.template',
            'docs': {},
            'time': time,
            'data': data,
        }
