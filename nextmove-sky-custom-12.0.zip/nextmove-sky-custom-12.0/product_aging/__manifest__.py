# -*- coding: utf-8 -*-
{
    'name': "product_aging",

    'summary': """
        zen""",

    'description': """
        Long description of module's purpose
    """,

    'author': "zen",
    'website': "http://www.yourcompany.com",

    
    'category': 'Uncategorized',
    'version': '0.2',

    # any module necessary for this one to work correctly
   'depends': ['base','stock', 'account','stock_account'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
       
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}