# -*- coding: utf-8 -*-
from odoo import http

# class ProductAging(http.Controller):
#     @http.route('/product_aging/product_aging/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/product_aging/product_aging/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('product_aging.listing', {
#             'root': '/product_aging/product_aging',
#             'objects': http.request.env['product_aging.product_aging'].search([]),
#         })

#     @http.route('/product_aging/product_aging/objects/<model("product_aging.product_aging"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('product_aging.object', {
#             'object': obj
#         })