# -*- coding: utf-8 -*-

from odoo import models, fields, api
import datetime 



class ProductTemplate(models.Model):
    _name = 'product.template'
    _inherit = 'product.template'
    purchase_dat = fields.Date(string='Purchase  Date', readonly=True, compute='_get_purchase_dat')
    agingpurchased_product_qty = fields.Float(compute='_compute_agingpurchased_product_qty', string='Purchased Qty')
    open_stock=fields.Monetary(string='Opening Stock', readonly=True, compute='_get_open_stock')
    sale_dat = fields.Date(string='Sales  Date', readonly=True, compute='_get_sale_dat')
    agingsales_count = fields.Float(compute='_compute_agingsales_count', string='Sold Qty')
    
    def _compute_agingsales_count(self):
        for rec in self:
            self.env.cr.execute("SELECT  product_qty from stock_move where (reference like %(ye)s OR reference like %(yep)s) and product_id=(select id from product_product where product_tmpl_id=%(mo)s) ",{'ye':'Delivery Note%','yep':'%OUT%','mo':rec.id })
            retail = self.env.cr.dictfetchall()
            if retail:
                open_stock=0
                for datum in retail:
                    open_stock+=datum['product_qty'] 
                rec.agingsales_count=open_stock
                
                
                
    def _compute_agingpurchased_product_qty(self):
        for rec in self:
            self.env.cr.execute("SELECT product_qty from stock_move where reference like %(ye)s and product_id=(select id from product_product where product_tmpl_id=%(mo)s) ",{'ye':'WH/IN/%','mo':rec.id })
            retail = self.env.cr.dictfetchall()
            if retail:
                open_stock=0
                for datum in retail:
                    open_stock+=datum['product_qty'] 
                rec.agingpurchased_product_qty=open_stock  
                
    def _get_purchase_dat(self):
        for rec in self:
            self.env.cr.execute("SELECT to_char(date, 'YYYY-MM-dd') as revenue_date from stock_move where reference like %(ye)s and product_id=(select id from product_product where product_tmpl_id=%(mo)s) ",{'ye':'WH/IN/%','mo':rec.id })
            retail = self.env.cr.dictfetchall()
            if retail:
                rec.purchase_dat=retail[0]['revenue_date']
            else:
                self.env.cr.execute("SELECT to_char(date, 'YYYY-MM-dd') as revenue_date from stock_move where reference like %(ye)s and product_id=(select id from product_product where product_tmpl_id=%(mo)s) ",{'ye':'INV:Beginning Inventory%','mo':rec.id })
                reta = self.env.cr.dictfetchall()
                if reta:
                    rec.purchase_dat=reta[0]['revenue_date']
   
    def _get_sale_dat(self):
        for rec in self:
            self.env.cr.execute("SELECT  to_char(date, 'YYYY-MM-dd') as revenue_date from stock_move where reference like %(ye)s and product_id=(select id from product_product where product_tmpl_id=%(mo)s) ",{'ye':'Delivery Note%','mo':rec.id })
            retail = self.env.cr.dictfetchall()
            if retail:
                rec.sale_dat=retail[0]['revenue_date']
                
                
    def _get_open_stock(self):
        for rec in self:
            self.env.cr.execute("SELECT * from stock_move where reference like %(ye)s and product_id=(select id from product_product where product_tmpl_id=%(mo)s) ",{'ye':'INV:Beginning Inventory%','mo':rec.id })
            retail = self.env.cr.dictfetchall()
            if retail:
                open_stock=0
                for datum in retail:
                    open_stock+=datum['product_qty'] 
                rec.open_stock=open_stock
            
           
