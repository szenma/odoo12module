# -*- coding: utf-8 -*-

from odoo import models, fields, api



class ProductTemplate(models.Model):
    _name = 'product.template'
    _inherit = 'product.template'
    almeera_itemcode = fields.Char(string='Almeera Itemcode')
    lulu_itemcode = fields.Char(string='Lulu Itemcode')
    cur_date= fields.Char(string='Current date',compute='_compute_cur_date',readonly=False)
    
    @api.depends('barcode')
    def _compute_cur_date(self):
        
        for pro in self:
            if pro.id and pro.barcode:
                barcode_ids = self.env['product.product'].search([('product_tmpl_id', '=', pro.id)],limit=1)
                
                #print(pro.barcode)
                self.env.cr.execute("SELECT * FROM product_barcode_multi WHERE product_id=%(ze)s and name=%(nam)s  limit 1",{'ze':barcode_ids.id ,'nam':pro.barcode}) 
                tra=self.env.cr.dictfetchone()
                
                if  tra:
                    print(tra['id'])
                else:
                    
                    self.env.cr.execute("INSERT INTO product_barcode_multi (name,product_id,create_uid ,create_date,write_uid,write_date)VALUES (%(name)s,%(product_id)s ,%(create_uid)s  ,%(create_date)s ,%(write_uid)s,%(write_date)s  )",{'name':pro.barcode,'product_id':barcode_ids.id,'create_uid':pro.create_uid.id ,'create_date':pro.create_date ,'write_uid':pro.write_uid.id ,'write_date':pro.write_date})
            pro.cur_date =  pro.create_date 

    
    
        
