# -*- coding: utf-8 -*-
from odoo import http

# class Barcod(http.Controller):
#     @http.route('/barcod/barcod/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/barcod/barcod/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('barcod.listing', {
#             'root': '/barcod/barcod',
#             'objects': http.request.env['barcod.barcod'].search([]),
#         })

#     @http.route('/barcod/barcod/objects/<model("barcod.barcod"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('barcod.object', {
#             'object': obj
#         })