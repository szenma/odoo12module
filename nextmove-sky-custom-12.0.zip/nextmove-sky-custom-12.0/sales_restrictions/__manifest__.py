# -*- coding: utf-8 -*-
{
    'name': "Sw - Sales Restictions",
    'summary': """
    This module allows the salesperson to see and to sell to his own customers only, also to add a delivery man per customer and to assign on DO.
       """,
    'description': """
    """,
    'author': "Smart Way Business Solutions",
    'website': "https://www.smartway.co",
    'category': 'Uncategorized',
     'version': '12.0.1.0',
    'depends': ['base','sale','hr','stock'],
    'data': [
        'views/view.xml'
    ],
}