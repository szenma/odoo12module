# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.osv import expression


class SaleOrder(models.Model):
    _inherit = 'sale.order'
    
    @api.model
    def _search(self, args, offset=0, limit=None, order=None, count=False, access_rights_uid=None):
        user = self.env.user 
        if user.has_group('sales_team.group_sale_salesman') and not(user.has_group('sales_team.group_sale_manager') or user.has_group('sales_team.group_sale_salesman_all_leads')):
            args = expression.AND([
               ['|', ('user_id', '=', self._uid), '|', ('partner_id.user_id', '=', self._uid), ('partner_id.user_id', '=', False)],
               args
            ])
        return super(SaleOrder, self)._search(args, offset, limit, order, count, access_rights_uid)
    
    
class ResPartner(models.Model):
    _inherit = 'res.partner'
    
    driver_id = fields.Many2one('hr.employee', string='Deliver Man')
    
    @api.model
    def _search(self, args, offset=0, limit=None, order=None, count=False, access_rights_uid=None):
        user = self.env.user 
        if user.has_group('sales_team.group_sale_salesman') and not(user.has_group('sales_team.group_sale_manager') or user.has_group('sales_team.group_sale_salesman_all_leads')):
            args = expression.AND([
               ['|', ('user_id', '=', self._uid), ('user_id', '=', False)],
               args
            ])
        res = super(ResPartner, self)._search(args, offset, limit, order, count, access_rights_uid)
        return res
    
    @api.model
    def name_search(self, name='', args=None, operator='ilike', limit=100):
        user = self.env.user 
        if user.has_group('sales_team.group_sale_salesman') and not(user.has_group('sales_team.group_sale_manager') or user.has_group('sales_team.group_sale_salesman_all_leads')):
            args_a = ['|', ('user_id', '=', self._uid), ('user_id', '=', False)]
            if args:
                args = expression.AND([args_a,args])
            else:
                args = args_a
        res = self._name_search(name, args, operator, limit=limit)
        return res 
    
     
class StockPicking(models.Model):
    _inherit = 'stock.picking'

    driver_id = fields.Many2one('hr.employee', readonly=True, string='Deliver Man')
    
    @api.model_create_multi
    @api.returns('self', lambda value: value.id)
    def create(self, vals_list):
        res = super(StockPicking, self).create(vals_list)
        for rec in res:
            if rec.partner_id:
                rec.driver_id = rec.partner_id.driver_id.id
        return res
    
    @api.multi
    def write(self, vals):
        if vals.get('partner_id', False):
            vals['driver_id'] = self.env['res.partner'].browse(vals.get('partner_id')).driver_id.id
        return super(StockPicking, self).write(vals)
