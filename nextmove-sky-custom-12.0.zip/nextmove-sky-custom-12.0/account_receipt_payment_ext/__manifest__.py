# -*- coding: utf-8 -*-
{
    'name': "SW - Account Receipt Payment",

    'summary': """
    This module extend account_receipt_payment , to show partner type field on payment to meet Sky requirements.
    """,
    'description': """
    This module extend account_receipt_payment , to show partner type field on payment to meet Sky requirements.
    """,
    'author': "Smart Way Business Solutions",
    'website': "https://www.smartway.co",
    'category': 'SKY',
    'version': '12.0.1.0',
    'depends': ['account_receipt_payment'],
    'data': [
        "views/payment_view.xml"
    ],
    'auto_install': True,
}
